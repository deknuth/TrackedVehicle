# faceDetector
This is an project of face detector. It provided a dynamic library.

## Version
1) windows release x86
2) windows release x64
3) linux release x64

## Usage
I programed a source file main.cpp. You can use it to test the library. The program rely on opencv.

## Library detail
This labrary provided there function, you can see in the file face_detector.h. 
And The model file is face_detector_model.bin.

## Others
If you want to get other platform library, you can send email to me. More information you can see in [my blog](http://blog.csdn.net/focusface).


